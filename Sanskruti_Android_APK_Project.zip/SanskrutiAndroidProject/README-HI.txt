SANSKRUTI FOOD DELIVERY - ANDROID PROJECT

यह Android APK बनाने के लिए source project है। यह ZIP खुद APK नहीं है।

APK बनाने का आसान cloud तरीका:
1. GitHub पर sign in करके नया repository बनाएं।
2. इस ZIP को extract करके इसके अंदर की सभी files repository में upload करें।
3. Repository में Actions tab खोलें।
4. "Build Sanskruti APK" workflow चुनकर Run workflow दबाएं।
5. Build पूरा होने पर नीचे Artifacts में "Sanskruti-Food-Delivery-APK" डाउनलोड करें।
6. ZIP artifact को extract करें। app-debug.apk को Android फोन पर install करें।
   फोन पूछे तो इस फाइल मैनेजर/ब्राउज़र के लिए "Install unknown apps" अनुमति दें।

ध्यान दें:
- यह debug APK है, Play Store publishing के लिए release-signed APK/AAB नहीं।
- पहली बार build के लिए internet और GitHub account जरूरी है।
- WhatsApp order link shop के दिए हुए नंबर पर खुलता है।
- APK install करने से पहले अपने फोन पर सभी order details और WhatsApp order flow test करें।
